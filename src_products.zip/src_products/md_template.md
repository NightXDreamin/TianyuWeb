---

productName: "KE系列型铅烟净化器"

category: "gas"

images:

&nbsp; - "/assets/img/products/gas/ke-purifier-1.jpg"

&nbsp; - "/assets/img/products/gas/ke-purifier-2.jpg"

seo:

&nbsp; title: "KE系列型铅烟净化器 - 铅烟治理 | 河南天昱环保"

&nbsp; description: "天昱环保KE系列铅烟净化器，国内最早铅尘治理设备，采用喷淋洗涤与旋流分离相结合，结构紧凑、占地小、净化效率高。适用于印刷、冶炼、制药、蓄电池等行业的铅烟尘及酸雾废气处理，运行稳定，维护简便。"

---





